package pokemon.movimientos;

public enum Clase {
    FISICO,
    ESPECIAL,
    ESTADO
}
